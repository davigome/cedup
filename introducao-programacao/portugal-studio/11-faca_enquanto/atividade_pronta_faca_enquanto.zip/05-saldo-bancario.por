programa
{
	
	funcao inicio()
	{
		inteiro opcao = 0
		inteiro saldo = 0
		inteiro valorDeposito = 0
		inteiro valorSaque = 0
		
		

		faca{
		escreva("1. Consultar saldo")
		escreva("\n2. Saque")
		escreva("\n3. Deposito")
		escreva("\n4. Sair\n")
		leia(opcao)
		limpa()

		se(opcao == 1 ){
		escreva("Saldo: R$"+saldo+"\n1 Voltar ")
		leia(opcao)
		limpa()
		
		}senao se(opcao == 2 ){
			faca{
			escreva("Saldo: R$ "+saldo+"\n")
			escreva("Insira o valor do saque: ")
			leia(valorSaque)
			escreva("\n1. Voltar")
			leia(valorSaque)
			limpa()

			saldo= (saldo - valorSaque)
			
			escreva("Valor minimo para saque 2 reais"+"\n")
			}enquanto(valorSaque >= 2 e opcao != 1)
		
		}senao se (opcao == 3 ){
		escreva("Saldo: R$ "+saldo+"\n")
		escreva("Insira o valor do Depósito; ")
		leia(valorDeposito)
		limpa()
		

		saldo= (saldo + valorDeposito)
		
		}senao 
			escreva("Exit! ")
		
		
		}enquanto(opcao != 4)
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 928; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = {opcao, 6, 10, 5}-{saldo, 7, 10, 5}-{valorDeposito, 8, 10, 13}-{valorSaque, 9, 10, 10};
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */