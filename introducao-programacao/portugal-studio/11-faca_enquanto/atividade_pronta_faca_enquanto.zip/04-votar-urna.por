programa
{
	
	funcao inicio()
	{	
		inteiro opcaoCandidato=0, votosManuel=0, votosZmaguinho=0, votosMctom=0, votosLucas=0, votosEdson=0, nulo=0, branco=0, votos=0, vencedor=0
		real porcentagemNulos, porcentagemBrancos
		
		faca{
			escreva(" As opções são:" +   
		"\n1. Candidato Manoel Gomes "+
		"\n2. Candidato Z-maguinho do Piauí "+
		"\n3. Candidato Mc Tom de Moletom "+
		"\n4. Candidato Sr Líder Lucas Meirelles"+
		"\n5. Candidato Sr Vice-líder Edson Sanson"+
		"\n6. Nulo"+
		"\n7. Branco"+
		"\n8. Sair"+
		"\n")
		leia(opcaoCandidato)

		se(opcaoCandidato == 1 ){
			votosManuel++
			votos++
		}senao se (opcaoCandidato == 2 ){
			votosZmaguinho++
			votos++
		}senao se (opcaoCandidato == 3 ){
			votosMctom++
			votos++
		}senao se (opcaoCandidato == 4 ){
			votosLucas++
			votos++
		}senao se (opcaoCandidato == 5 ){
			votosEdson++
			votos++
		}senao se (opcaoCandidato == 6 ){
			nulo++
			votos++
		}senao se (opcaoCandidato == 7 ){
			branco++
			votos++
		}senao {}
		limpa()

		}enquanto(opcaoCandidato != 8)

		porcentagemNulos = (nulo*votos)/votos

		porcentagemBrancos = (branco*votos)/votos

		se(votosManuel > votosZmaguinho e votosManuel>votosMctom e votosManuel>votosLucas e votosManuel> votosEdson){
	escreva("o canditado vencedor é Manoel Gomes!")
	}
	senao se(votosZmaguinho > votosManuel e votosZmaguinho>votosMctom e votosZmaguinho>votosLucas e votosZmaguinho> votosEdson){
	escreva("o candidato vencedor é Z-maguinho do Piauí")
	}
	senao se(votosMctom > votosManuel e votosMctom>votosZmaguinho e votosMctom>votosLucas e votosMctom> votosEdson){
	escreva("o candidato vencedor é Mc Tom de Moletom")
	}
	senao se(votosLucas > votosManuel e votosLucas>votosMctom e votosEdson>votosZmaguinho e votosLucas> votosEdson){
	escreva("o candidato vencedor é Sr Líder Lucas Meirelles ")
	}
	senao se(votosEdson > votosManuel e votosEdson>votosMctom e votosEdson>votosLucas e votosEdson> votosZmaguinho){
	escreva("o candidato vencedor é Sr Vice-líder Edson Sanson")
	}senao{
		escreva("a votação deu empate!\n")
		}

			escreva(
		"\nO número de votos de cada candidato:\n\n"
		+ votosManuel + " - Manoel Gomes\n"
		+ votosZmaguinho + " - Z-maguinho do Piauí\n"
		+ votosMctom + " - Mc Tom de Moletom\n"
		+ votosLucas + " - Sr Líder Lucas Meirelles\n"
		+ votosEdson + " - Sr Vice-líder Edson Sanson\n\n"
		
		+ "Porcentagem de votos nulos: "
		+ porcentagemNulos + "%\n"
		
		+ "Porcentagem de votos brancos: "
		+ porcentagemBrancos + "%\n"
		)
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 2139; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */