programa
{
	
	funcao inicio()
	{	
		inteiro senha, validar=0

		escreva("Crie uma senha de 4 dígitos: ")
		leia(senha)
		limpa()

		faca{
			
			escreva("Digite a senha: ")
			leia(validar)
			
			}enquanto(validar != senha )
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 231; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */