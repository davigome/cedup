programa
{
	
	funcao inicio()
	{	

	//BLOCO DE CÓDIGO 1 - DECLARAÇÃO  -----------------------------------------------------------------
	
		inteiro numero //guarda o número digitado
		inteiro i=1 //usado para contar no laço, e o inteiro significa para guardar um número com valor de inteiro.
		
	//BLOCO DE CÓDIGO 2 ENTRADA DE DADOS ---------------------------------------------------------------
	
		escreva("Digite um número inteiro: ")
		leia(numero)

	//BLOCO DE CÓDIGO 3 LAÇO DE REPETIÇÃO COM AS CONDIÇÕES DE COMPARAÇÃO -------------------------------
	
		faca{
			
		se(i % 2 != 0){ // verificar se é impar [O % pega o resto da divisão.]
					// Se o número for diferente de 0, então é impar
			escreva(i, "\n") //mostrar o número 
			}

		i++ //incrementar
			
		}enquanto(i <= numero)//verificação do enquanto
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 15; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */